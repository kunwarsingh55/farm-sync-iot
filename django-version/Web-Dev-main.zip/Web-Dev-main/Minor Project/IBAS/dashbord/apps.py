from django.apps import AppConfig


class DashbordConfig(AppConfig):
    name = 'dashbord'
